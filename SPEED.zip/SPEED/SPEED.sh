clear
blue='\033[34;1m'
green='\033[32;1m'  
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'                                           
yellow='\033[33;1m'
sleep 1
echo
echo $red
cat baca.txt
sleep 10
echo $green
figlet "SPEED"
echo $purple"<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $white"Author : FAIZAL STABILKAN JARINGAN"
echo $cyan"Kontak : 01140320764"
echo $red"SUBSCRIBE :" $yellow"Official Faizal Ganz"
echo $purple"<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $green"     SELAMAT DATANG BRO"
echo
echo $yellow"Silahkan Pilih Script Kesukaanmu :"
echo
echo $blue"1.) Stabilkan Jaringan v1"
echo "<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $yellow"2.) Stabilkan Jaringan v2"
echo "<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $white"3.) Stabilkan Jaringan Saat Browsing"
echo "<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $red"4.) Stabilkan Jaringan Saat nonton Youtube v1"
echo "<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $green"5.) Stabilkan Jaringan Saat nonton Youtube v2"
echo "<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $blue"6.) Stabilkan Jaringan Saat Chattingan Facebook v1"
echo "<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $yellow"7.) Stabilkan Jaringan Saat Chattingan Facebook v2"
echo "<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $purple"8.) Stabilkan Jaringan Saat Chattingan Instagram"
echo "<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $white"9.) Coming Soon...."
echo $yellow"<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $red"0.) KELUAR AJALAH"
echo "<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $green
figlet "BONUS"
echo " BUKA BONUS...(Ketik Buka)"
echo $cyan"<{≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈}>"
echo $green
read -p "Silahkan Pilih No Berapa : " bro

if [ $bro = 1 ] || [ $bro = 1 ]
then
clear
toilet -f big -F gay Yadi
echo $green"Stabilkan Jaringan v1 by Yadi"
sleep 1
echo
ping -s1000 1.1.1.1
fi

if [ $bro = 2 ] || [ $bro = 2 ]
then
clear
toilet -f big -F gay Yadi
echo $yellow"Stabilkan Jaringan v2 by Yadi"
sleep 1
echo
ping -s1000 8.8.8.8
fi

if [ $bro = 3 ] || [ $bro = 3 ]
then
clear
echo $green
figlet "By Yadi"
echo $white"Insya Allah Browsing Lancar"
sleep 1
echo
ping -s1000 216.239.38.120
fi

if [ $bro = 4 ] || [ $bro = 4 ]
then
clear
echo $red
figlet "Y T v 1"
echo "Stabilkan jaringan saat nonton Youtube v1 by Faizal"
sleep 2
echo
ping -s1000 74.125.24.91
fi

if [ $bro = 5 ] || [ $bro = 5 ]
then
clear
echo $red
figlet "Y T v 2"
echo "Stabilkan jaringan saat nonton Youtube v2 by Faizal"
sleep 2
echo
ping -s1000 172.217.194.113
fi

if [ $bro = 6 ] || [ $bro = 6 ]
then
clear
echo $blue
figlet "F B v 1"
echo "Stabilkan jaringan saat Chattingan Facebook v1 by Faizal"
sleep 2
echo
ping -s1000 157.240.7.35
fi

if [ $bro = 7 ] || [ $bro = 7 ]
then
clear
echo $blue
figlet "F B v 2"
echo "Stabilkan jaringan saat Chattingan Facebook v2 by Faizal"
sleep 2
echo
ping -s1000 157.240.25.35
fi

if [ $bro = 8 ] || [ $bro = 8 ]
then
clear
echo $purple
figlet "I G"
echo "Stabilkan jaringan saat Chattingan Instagram by Faizal"
sleep 2
echo
ping -s1000 157.240.7.174
fi

if [ $bro = 9 ] || [ $bro = 9 ]
then
clear
echo $white
figlet "Coming"
figlet "Soon"
sleep 2
echo $green"Tunggu script Ter update berikutnya"
sleep 3
echo $yellow"SEMOGA SCRIPT INI BERMANFAAT"
sleep 2
echo $white"Sampai Jumpa Lagi Di Script Berikutnya....:)"
sleep 2
exit
fi

if [ $bro = 0 ] || [ $bro = 0 ]
then
clear
echo $yellow
figlet "Yadi  F."
echo $green"SEMOGA HARIMU MENYENANGKAN...:)"
sleep 2
echo $white"     TO BE CONTINUED..."
echo
sleep 1
exit
fi

if [ $bro = Buka ] || [ $bro = Buka ]
then
clear
echo $yellow
figlet "Dark-Fb"
sleep 2
echo $green"Apakah Kamu Yakin Ingin Menginstall Dark-Fb v1.6 By Faizal ?"
sleep 3
echo $yellow"Kalau tidak tekan ctrl + c"
sleep 2
echo $white"Tapi Kalau Iya, Tunggu Sampai 15 detik"
sleep 15
pkg update && pkg upgrade
pkg install git
pkg install python2
pip2 install mechanize
pip2 install requests
git clone https://github.com/YadiFernando/DARKFB
mv DARKFB $HOME
cd $HOME/DARKFB
python2 DARKFB.py
fi
